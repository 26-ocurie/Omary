#!/usr/bin/env python3
"""
Ocurie Luxury HMS — One-command startup
Usage:  python3 start.py
        python3 start.py --port 8080
        python3 start.py --reset   (wipe & reseed database)
"""
import os, sys, subprocess, argparse, webbrowser, time, pathlib

ROOT = pathlib.Path(__file__).parent
BACKEND = ROOT / "backend"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port",  type=int, default=int(os.environ.get("PORT", 5000)))
    ap.add_argument("--reset", action="store_true", help="Wipe and reseed the database")
    ap.add_argument("--no-browser", action="store_true")
    args = ap.parse_args()

    db = BACKEND / "ocurie_hms.db"

    # Always init if DB missing or --reset
    if not db.exists() or args.reset:
        if args.reset and db.exists():
            db.unlink()
            print("🗑  Database wiped")
        print("🔧  Initialising database…")
        subprocess.run([sys.executable, str(BACKEND / "init_db.py")], cwd=str(BACKEND), check=True)

    url = f"http://localhost:{args.port}"
    print(f"\n✅  Ocurie Luxury HMS starting on {url}")
    print("    Admin login: admin / admin123")
    print("    Press Ctrl+C to stop\n")

    if not args.no_browser:
        # Open browser after 2 seconds
        def _open():
            time.sleep(2)
            webbrowser.open(url)
        import threading
        threading.Thread(target=_open, daemon=True).start()

    os.environ["PORT"] = str(args.port)
    os.chdir(str(BACKEND))
    os.execv(sys.executable, [sys.executable, str(BACKEND / "app.py")])

if __name__ == "__main__":
    main()
