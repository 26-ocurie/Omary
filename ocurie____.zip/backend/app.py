#!/usr/bin/env python3
"""
Ocurie Luxury HMS — Flask REST API
"""
import os, sqlite3, hashlib, json, uuid, pathlib
from datetime import datetime, timedelta
from functools import wraps
from flask import Flask, request, jsonify, g, send_from_directory

import jwt as pyjwt

# ── CONFIG ─────────────────────────────────────────────────────────────
_HERE     = pathlib.Path(__file__).parent          # backend/
_FRONTEND = str(_HERE.parent / "frontend")         # ../frontend  (absolute)

app = Flask(__name__, static_folder=_FRONTEND, static_url_path="")

SECRET_KEY    = os.environ.get("SECRET_KEY", "ocurie-luxury-secret-2026-change-in-prod")
_DEFAULT_DB   = str(_HERE / "ocurie_hms.db")
DB_PATH       = os.environ.get("DATABASE_PATH", _DEFAULT_DB)
TOKEN_EXPIRY  = int(os.environ.get("TOKEN_EXPIRY_HOURS", "12"))

# ── DATABASE ────────────────────────────────────────────────────────────
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA journal_mode=WAL")
        g.db.execute("PRAGMA foreign_keys=ON")
    return g.db

@app.teardown_appcontext
def close_db(e=None):
    db = g.pop("db", None)
    if db: db.close()

def query(sql, params=(), one=False):
    db  = get_db()
    cur = db.execute(sql, params)
    return (cur.fetchone() if one else cur.fetchall())

def mutate(sql, params=()):
    db = get_db()
    cur = db.execute(sql, params)
    db.commit()
    return cur

def uid():
    return str(uuid.uuid4())

def now_str():
    return datetime.utcnow().isoformat()

# ── AUTH ────────────────────────────────────────────────────────────────
ROLE_PERMISSIONS = {
    "admin":         ["*"],
    "manager":       ["dashboard","rooms","reservations","checkin","billing","guests","housekeeping","reports","notifications","staff:read"],
    "receptionist":  ["dashboard","rooms","reservations","checkin","billing","guests","notifications"],
    "housekeeper":   ["housekeeping","rooms","notifications"],
}

def hash_pw(pw):
    return hashlib.sha256(pw.encode()).hexdigest()

def make_token(user_row):
    payload = {
        "sub":  user_row["id"],
        "un":   user_row["username"],
        "role": user_row["role"],
        "name": user_row["name"],
        "exp":  datetime.utcnow() + timedelta(hours=TOKEN_EXPIRY),
        "iat":  datetime.utcnow(),
    }
    return pyjwt.encode(payload, SECRET_KEY, algorithm="HS256")

def decode_token(token):
    return pyjwt.decode(token, SECRET_KEY, algorithms=["HS256"])

def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        auth = request.headers.get("Authorization","")
        if not auth.startswith("Bearer "):
            return jsonify({"error":"Missing token"}), 401
        try:
            g.user = decode_token(auth.split(" ",1)[1])
        except pyjwt.ExpiredSignatureError:
            return jsonify({"error":"Token expired"}), 401
        except Exception:
            return jsonify({"error":"Invalid token"}), 401
        return f(*args, **kwargs)
    return wrapper

def require_roles(*roles):
    """Allow access only if the current user's role is in `roles` OR they are admin."""
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            user_role = g.user.get("role","")
            if user_role != "admin" and user_role not in roles:
                return jsonify({"error":"Forbidden — insufficient permissions"}), 403
            return f(*args, **kwargs)
        return wrapper
    return decorator

def row_to_dict(row):
    if row is None: return None
    return {k: row[k] for k in row.keys()}

def rows_to_list(rows):
    return [row_to_dict(r) for r in rows]

def audit(action, entity_type=None, entity_id=None, details=None):
    try:
        user_id = g.user.get("sub") if hasattr(g,"user") else None
        mutate("""INSERT INTO audit_log(id,user_id,action,entity_type,entity_id,details,ip_address)
                  VALUES(?,?,?,?,?,?,?)""",
               (uid(), user_id, action, entity_type, entity_id,
                json.dumps(details) if details else None,
                request.remote_addr))
    except Exception:
        pass

# ── CORS HEADERS ────────────────────────────────────────────────────────
@app.after_request
def add_cors(resp):
    resp.headers["Access-Control-Allow-Origin"]  = "*"
    resp.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization"
    resp.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, PATCH, OPTIONS"
    return resp

@app.route("/<path:p>", methods=["OPTIONS"])
@app.route("/", methods=["OPTIONS"])
def options_handler(p=""):
    return "", 204

# ── SERVE FRONTEND ──────────────────────────────────────────────────────
@app.route("/")
def index():
    return send_from_directory(app.static_folder, "index.html")

# ══════════════════════════════════════════════════════════════════════════
# AUTH ROUTES
# ══════════════════════════════════════════════════════════════════════════
@app.route("/api/auth/login", methods=["POST"])
def login():
    body = request.get_json(force=True)
    username = (body.get("username") or "").strip().lower()
    password = body.get("password") or ""
    if not username or not password:
        return jsonify({"error":"Username and password required"}), 400
    user = query("SELECT * FROM users WHERE username=? AND status='active'", (username,), one=True)
    if not user or user["password_hash"] != hash_pw(password):
        return jsonify({"error":"Invalid credentials"}), 401
    token = make_token(user)
    audit("LOGIN", "user", user["id"])
    return jsonify({
        "token": token,
        "user": {
            "id":    user["id"],
            "name":  user["name"],
            "role":  user["role"],
            "username": user["username"],
            "avatar_color": user["avatar_color"],
            "permissions": ROLE_PERMISSIONS.get(user["role"], []),
        }
    })

@app.route("/api/auth/me", methods=["GET"])
@login_required
def me():
    user = query("SELECT * FROM users WHERE id=?", (g.user["sub"],), one=True)
    if not user: return jsonify({"error":"Not found"}), 404
    return jsonify(row_to_dict(user))

@app.route("/api/auth/change-password", methods=["POST"])
@login_required
def change_password():
    body = request.get_json(force=True)
    old  = body.get("old_password","")
    new  = body.get("new_password","")
    if not old or not new or len(new) < 6:
        return jsonify({"error":"Old password and new password (min 6 chars) required"}), 400
    user = query("SELECT * FROM users WHERE id=?", (g.user["sub"],), one=True)
    if not user or user["password_hash"] != hash_pw(old):
        return jsonify({"error":"Current password incorrect"}), 400
    mutate("UPDATE users SET password_hash=?,updated_at=? WHERE id=?",
           (hash_pw(new), now_str(), g.user["sub"]))
    audit("CHANGE_PASSWORD","user",g.user["sub"])
    return jsonify({"message":"Password updated"})

# ══════════════════════════════════════════════════════════════════════════
# DASHBOARD
# ══════════════════════════════════════════════════════════════════════════
@app.route("/api/dashboard", methods=["GET"])
@login_required
def dashboard():
    today = datetime.utcnow().strftime("%Y-%m-%d")

    room_stats = query("""
        SELECT status, COUNT(*) as cnt FROM rooms GROUP BY status
    """)
    room_counts = {r["status"]: r["cnt"] for r in room_stats}
    total_rooms = sum(room_counts.values())

    checkins_today  = query("SELECT COUNT(*) as c FROM reservations WHERE check_in=?  AND status NOT IN ('cancelled','no_show')", (today,), one=True)["c"]
    checkouts_today = query("SELECT COUNT(*) as c FROM reservations WHERE check_out=? AND status NOT IN ('cancelled','no_show')", (today,), one=True)["c"]

    rev_today = query("""
        SELECT COALESCE(SUM(i.paid_amount),0) as rev
        FROM invoices i
        WHERE date(i.issued_at)=?
    """, (today,), one=True)["rev"]

    rev_month = query("""
        SELECT COALESCE(SUM(i.paid_amount),0) as rev
        FROM invoices i
        WHERE strftime('%Y-%m',i.issued_at)=strftime('%Y-%m','now')
    """, one=True)["rev"]

    recent = query("""
        SELECT r.res_number, r.status, r.check_in, r.check_out,
               g.first_name||' '||g.last_name as guest_name,
               rm.number as room_number
        FROM reservations r
        JOIN guests g  ON r.guest_id=g.id
        JOIN rooms  rm ON r.room_id=rm.id
        ORDER BY r.created_at DESC LIMIT 10
    """)

    hk_pending = query("SELECT COUNT(*) as c FROM housekeeping WHERE status='pending'", one=True)["c"]
    invoices_pending = query("SELECT COUNT(*) as c FROM invoices WHERE status='pending'", one=True)["c"]

    return jsonify({
        "rooms": {
            "total":       total_rooms,
            "available":   room_counts.get("available",0),
            "occupied":    room_counts.get("occupied",0),
            "cleaning":    room_counts.get("cleaning",0),
            "maintenance": room_counts.get("maintenance",0),
            "reserved":    room_counts.get("reserved",0),
            "occupancy_pct": round(room_counts.get("occupied",0)/total_rooms*100,1) if total_rooms else 0,
        },
        "today": {
            "checkins":  checkins_today,
            "checkouts": checkouts_today,
            "revenue":   round(rev_today, 2),
        },
        "month": {"revenue": round(rev_month, 2)},
        "pending": {"housekeeping": hk_pending, "invoices": invoices_pending},
        "recent_reservations": rows_to_list(recent),
    })

# ══════════════════════════════════════════════════════════════════════════
# ROOMS
# ══════════════════════════════════════════════════════════════════════════
@app.route("/api/rooms", methods=["GET"])
@login_required
def get_rooms():
    status = request.args.get("status")
    rtype  = request.args.get("type")
    floor  = request.args.get("floor")
    sql    = "SELECT * FROM rooms WHERE 1=1"
    params = []
    if status: sql += " AND status=?";  params.append(status)
    if rtype:  sql += " AND type=?";    params.append(rtype)
    if floor:  sql += " AND floor=?";   params.append(floor)
    sql += " ORDER BY CAST(number AS INTEGER)"
    rooms = query(sql, params)
    result = []
    for r in rooms:
        d = row_to_dict(r)
        d["amenities"] = json.loads(d.get("amenities","[]"))
        result.append(d)
    return jsonify(result)

@app.route("/api/rooms/<room_id>", methods=["GET"])
@login_required
def get_room(room_id):
    room = query("SELECT * FROM rooms WHERE id=?", (room_id,), one=True)
    if not room: return jsonify({"error":"Not found"}),404
    d = row_to_dict(room)
    d["amenities"] = json.loads(d.get("amenities","[]"))
    return jsonify(d)

@app.route("/api/rooms/<room_id>/status", methods=["PATCH"])
@login_required
@require_roles("admin","manager","receptionist")
def update_room_status(room_id):
    body   = request.get_json(force=True)
    status = body.get("status")
    valid  = ["available","occupied","cleaning","maintenance","reserved"]
    if status not in valid:
        return jsonify({"error":f"Status must be one of {valid}"}),400
    mutate("UPDATE rooms SET status=?,updated_at=? WHERE id=?", (status,now_str(),room_id))
    audit("UPDATE_ROOM_STATUS","room",room_id,{"status":status})
    return jsonify({"message":"Updated","status":status})

@app.route("/api/rooms", methods=["POST"])
@login_required
@require_roles("admin","manager")
def create_room():
    b = request.get_json(force=True)
    required = ["number","type","price_per_night"]
    for f in required:
        if not b.get(f):
            return jsonify({"error":f"{f} is required"}),400
    existing = query("SELECT id FROM rooms WHERE number=?", (b["number"],), one=True)
    if existing: return jsonify({"error":"Room number already exists"}),409
    rid = uid()
    mutate("""INSERT INTO rooms(id,number,type,floor,status,price_per_night,capacity,amenities,description,notes)
              VALUES(?,?,?,?,?,?,?,?,?,?)""",
           (rid, b["number"], b["type"], b.get("floor",1), "available",
            b["price_per_night"], b.get("capacity",2),
            json.dumps(b.get("amenities",[])), b.get("description",""), b.get("notes","")))
    audit("CREATE_ROOM","room",rid,{"number":b["number"]})
    return jsonify({"id":rid,"message":"Room created"}),201

@app.route("/api/rooms/<room_id>", methods=["PUT"])
@login_required
@require_roles("admin","manager")
def update_room(room_id):
    b = request.get_json(force=True)
    mutate("""UPDATE rooms SET type=?,floor=?,price_per_night=?,capacity=?,
              amenities=?,description=?,notes=?,updated_at=? WHERE id=?""",
           (b.get("type"), b.get("floor",1), b.get("price_per_night"),
            b.get("capacity",2), json.dumps(b.get("amenities",[])),
            b.get("description",""), b.get("notes",""), now_str(), room_id))
    audit("UPDATE_ROOM","room",room_id)
    return jsonify({"message":"Updated"})

@app.route("/api/rooms/<room_id>", methods=["DELETE"])
@login_required
@require_roles("admin")
def delete_room(room_id):
    active = query("SELECT id FROM reservations WHERE room_id=? AND status IN ('confirmed','checked_in')", (room_id,), one=True)
    if active: return jsonify({"error":"Cannot delete room with active reservations"}),409
    mutate("DELETE FROM rooms WHERE id=?", (room_id,))
    audit("DELETE_ROOM","room",room_id)
    return jsonify({"message":"Deleted"})

# ══════════════════════════════════════════════════════════════════════════
# GUESTS
# ══════════════════════════════════════════════════════════════════════════
@app.route("/api/guests", methods=["GET"])
@login_required
def get_guests():
    q  = (request.args.get("q") or "").strip()
    vip = request.args.get("vip")
    sql = """SELECT g.*,
             (SELECT COUNT(*) FROM reservations r WHERE r.guest_id=g.id) as stay_count
             FROM guests g WHERE 1=1"""
    params = []
    if q:
        sql += " AND (g.first_name||' '||g.last_name LIKE ? OR g.email LIKE ? OR g.phone LIKE ?)"
        params += [f"%{q}%",f"%{q}%",f"%{q}%"]
    if vip == "1": sql += " AND g.vip=1"
    sql += " ORDER BY g.last_name, g.first_name"
    return jsonify(rows_to_list(query(sql, params)))

@app.route("/api/guests/<gid>", methods=["GET"])
@login_required
def get_guest(gid):
    g = query("SELECT * FROM guests WHERE id=?", (gid,), one=True)
    if not g: return jsonify({"error":"Not found"}),404
    res = query("""SELECT r.*,rm.number as room_number,rm.type as room_type
                   FROM reservations r JOIN rooms rm ON r.room_id=rm.id
                   WHERE r.guest_id=? ORDER BY r.created_at DESC""", (gid,))
    d = row_to_dict(g)
    d["reservations"] = rows_to_list(res)
    return jsonify(d)

@app.route("/api/guests", methods=["POST"])
@login_required
@require_roles("admin","manager","receptionist")
def create_guest():
    b = request.get_json(force=True)
    if not b.get("first_name") or not b.get("last_name"):
        return jsonify({"error":"first_name and last_name required"}),400
    gid = uid()
    mutate("""INSERT INTO guests(id,first_name,last_name,email,phone,nationality,id_type,id_number,vip,notes)
              VALUES(?,?,?,?,?,?,?,?,?,?)""",
           (gid, b["first_name"], b["last_name"],
            b.get("email",""), b.get("phone",""), b.get("nationality",""),
            b.get("id_type","Passport"), b.get("id_number",""),
            1 if b.get("vip") else 0, b.get("notes","")))
    audit("CREATE_GUEST","guest",gid,{"name":b["first_name"]+" "+b["last_name"]})
    return jsonify({"id":gid,"message":"Guest created"}),201

@app.route("/api/guests/<gid>", methods=["PUT"])
@login_required
@require_roles("admin","manager","receptionist")
def update_guest(gid):
    b = request.get_json(force=True)
    mutate("""UPDATE guests SET first_name=?,last_name=?,email=?,phone=?,
              nationality=?,id_type=?,id_number=?,vip=?,notes=?,updated_at=?
              WHERE id=?""",
           (b.get("first_name"), b.get("last_name"), b.get("email",""),
            b.get("phone",""), b.get("nationality",""), b.get("id_type","Passport"),
            b.get("id_number",""), 1 if b.get("vip") else 0,
            b.get("notes",""), now_str(), gid))
    audit("UPDATE_GUEST","guest",gid)
    return jsonify({"message":"Updated"})

@app.route("/api/guests/<gid>", methods=["DELETE"])
@login_required
@require_roles("admin","manager")
def delete_guest(gid):
    active = query("SELECT id FROM reservations WHERE guest_id=? AND status IN ('confirmed','checked_in')", (gid,), one=True)
    if active: return jsonify({"error":"Cannot delete guest with active reservations"}),409
    mutate("DELETE FROM guests WHERE id=?", (gid,))
    audit("DELETE_GUEST","guest",gid)
    return jsonify({"message":"Deleted"})

# ══════════════════════════════════════════════════════════════════════════
# RESERVATIONS
# ══════════════════════════════════════════════════════════════════════════
@app.route("/api/reservations", methods=["GET"])
@login_required
def get_reservations():
    status  = request.args.get("status")
    date    = request.args.get("date")    # check_in date filter
    guest_q = request.args.get("guest_q","")
    sql = """SELECT r.*,
             g.first_name||' '||g.last_name as guest_name, g.email as guest_email,
             g.phone as guest_phone, g.vip as guest_vip,
             rm.number as room_number, rm.type as room_type, rm.price_per_night
             FROM reservations r
             JOIN guests g  ON r.guest_id=g.id
             JOIN rooms  rm ON r.room_id=rm.id
             WHERE 1=1"""
    params = []
    if status:  sql += " AND r.status=?";                  params.append(status)
    if date:    sql += " AND r.check_in=?";                params.append(date)
    if guest_q: sql += " AND (g.first_name||' '||g.last_name LIKE ?)"; params.append(f"%{guest_q}%")
    sql += " ORDER BY r.created_at DESC"
    return jsonify(rows_to_list(query(sql, params)))

@app.route("/api/reservations/<rid>", methods=["GET"])
@login_required
def get_reservation(rid):
    r = query("""SELECT r.*,
                 g.first_name||' '||g.last_name as guest_name,
                 g.email as guest_email, g.phone as guest_phone,
                 rm.number as room_number, rm.type as room_type
                 FROM reservations r
                 JOIN guests g  ON r.guest_id=g.id
                 JOIN rooms  rm ON r.room_id=rm.id
                 WHERE r.id=?""", (rid,), one=True)
    if not r: return jsonify({"error":"Not found"}),404
    return jsonify(row_to_dict(r))

@app.route("/api/reservations", methods=["POST"])
@login_required
@require_roles("admin","manager","receptionist")
def create_reservation():
    b = request.get_json(force=True)
    required = ["guest_id","room_id","check_in","check_out"]
    for f in required:
        if not b.get(f): return jsonify({"error":f"{f} required"}),400

    ci = datetime.strptime(b["check_in"],"%Y-%m-%d")
    co = datetime.strptime(b["check_out"],"%Y-%m-%d")
    if co <= ci: return jsonify({"error":"Check-out must be after check-in"}),400

    # Check room availability
    conflict = query("""SELECT id FROM reservations
                        WHERE room_id=? AND status IN ('confirmed','checked_in')
                        AND NOT (check_out<=? OR check_in>=?)""",
                     (b["room_id"], b["check_in"], b["check_out"]), one=True)
    if conflict: return jsonify({"error":"Room not available for selected dates"}),409

    room = query("SELECT * FROM rooms WHERE id=?", (b["room_id"],), one=True)
    if not room: return jsonify({"error":"Room not found"}),404

    nights = (co - ci).days
    total  = nights * room["price_per_night"]

    # Generate res number
    count  = query("SELECT COUNT(*) as c FROM reservations", one=True)["c"]
    res_no = f"RES-{count+1:04d}"
    rid    = uid()

    mutate("""INSERT INTO reservations
              (id,res_number,guest_id,room_id,check_in,check_out,nights,adults,children,
               total_amount,paid_amount,status,payment_method,special_requests,notes,created_by)
              VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
           (rid, res_no, b["guest_id"], b["room_id"],
            b["check_in"], b["check_out"], nights,
            b.get("adults",2), b.get("children",0),
            total, 0, "confirmed",
            b.get("payment_method","Credit Card"),
            b.get("special_requests",""), b.get("notes",""),
            g.user["sub"]))

    # Update room status to reserved
    mutate("UPDATE rooms SET status='reserved',updated_at=? WHERE id=?", (now_str(), b["room_id"]))

    audit("CREATE_RESERVATION","reservation",rid,{"res_no":res_no})
    return jsonify({"id":rid,"res_number":res_no,"total":total,"message":"Reservation created"}),201

@app.route("/api/reservations/<rid>/checkin", methods=["POST"])
@login_required
@require_roles("admin","manager","receptionist")
def checkin(rid):
    res = query("SELECT * FROM reservations WHERE id=?", (rid,), one=True)
    if not res: return jsonify({"error":"Not found"}),404
    if res["status"] != "confirmed": return jsonify({"error":"Reservation is not in confirmed state"}),400
    mutate("UPDATE reservations SET status='checked_in',updated_at=? WHERE id=?", (now_str(),rid))
    mutate("UPDATE rooms SET status='occupied',updated_at=? WHERE id=?", (now_str(),res["room_id"]))
    audit("CHECKIN","reservation",rid)
    return jsonify({"message":"Checked in"})

@app.route("/api/reservations/<rid>/checkout", methods=["POST"])
@login_required
@require_roles("admin","manager","receptionist")
def checkout(rid):
    res = query("SELECT * FROM reservations WHERE id=?", (rid,), one=True)
    if not res: return jsonify({"error":"Not found"}),404
    if res["status"] != "checked_in": return jsonify({"error":"Guest is not checked in"}),400
    mutate("UPDATE reservations SET status='checked_out',updated_at=? WHERE id=?", (now_str(),rid))
    mutate("UPDATE rooms SET status='cleaning',updated_at=? WHERE id=?", (now_str(),res["room_id"]))
    # auto-create housekeeping task
    mutate("""INSERT INTO housekeeping(id,room_id,priority,task_type,notes,status)
              VALUES(?,?,'High','cleaning','Post checkout clean','pending')""",
           (uid(), res["room_id"]))
    audit("CHECKOUT","reservation",rid)
    return jsonify({"message":"Checked out"})

@app.route("/api/reservations/<rid>/cancel", methods=["POST"])
@login_required
@require_roles("admin","manager","receptionist")
def cancel_reservation(rid):
    res = query("SELECT * FROM reservations WHERE id=?", (rid,), one=True)
    if not res: return jsonify({"error":"Not found"}),404
    if res["status"] in ("checked_out","cancelled"):
        return jsonify({"error":"Cannot cancel this reservation"}),400
    mutate("UPDATE reservations SET status='cancelled',updated_at=? WHERE id=?", (now_str(),rid))
    mutate("UPDATE rooms SET status='available',updated_at=? WHERE id=?", (now_str(),res["room_id"]))
    audit("CANCEL_RESERVATION","reservation",rid)
    return jsonify({"message":"Cancelled"})

@app.route("/api/reservations/<rid>", methods=["DELETE"])
@login_required
@require_roles("admin")
def delete_reservation(rid):
    mutate("DELETE FROM reservations WHERE id=?", (rid,))
    audit("DELETE_RESERVATION","reservation",rid)
    return jsonify({"message":"Deleted"})

# ══════════════════════════════════════════════════════════════════════════
# STAFF (USERS)
# ══════════════════════════════════════════════════════════════════════════
@app.route("/api/staff", methods=["GET"])
@login_required
def get_staff():
    role  = request.args.get("role")
    dept  = request.args.get("department")
    sql   = "SELECT id,username,name,role,department,shift,phone,email,status,avatar_color,created_at FROM users WHERE 1=1"
    params= []
    if role: sql += " AND role=?";       params.append(role)
    if dept: sql += " AND department=?"; params.append(dept)
    sql += " ORDER BY name"
    return jsonify(rows_to_list(query(sql, params)))

@app.route("/api/staff/<uid_>", methods=["GET"])
@login_required
def get_staff_member(uid_):
    u = query("SELECT id,username,name,role,department,shift,phone,email,status,avatar_color,created_at FROM users WHERE id=?", (uid_,), one=True)
    if not u: return jsonify({"error":"Not found"}),404
    return jsonify(row_to_dict(u))

@app.route("/api/staff", methods=["POST"])
@login_required
@require_roles("admin","manager")
def create_staff():
    b = request.get_json(force=True)
    if not b.get("username") or not b.get("name") or not b.get("role"):
        return jsonify({"error":"username, name and role required"}),400
    if not b.get("password") or len(b["password"]) < 6:
        return jsonify({"error":"Password min 6 chars"}),400
    exists = query("SELECT id FROM users WHERE username=?", (b["username"],), one=True)
    if exists: return jsonify({"error":"Username already taken"}),409
    new_id = uid()
    mutate("""INSERT INTO users(id,username,password_hash,name,role,department,shift,phone,email,status,avatar_color)
              VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
           (new_id, b["username"].lower(), hash_pw(b["password"]),
            b["name"], b["role"],
            b.get("department","General"), b.get("shift","Morning"),
            b.get("phone",""), b.get("email",""), "active",
            b.get("avatar_color","#C9A84C")))
    audit("CREATE_STAFF","user",new_id,{"username":b["username"]})
    return jsonify({"id":new_id,"message":"Staff created"}),201

@app.route("/api/staff/<uid_>", methods=["PUT"])
@login_required
@require_roles("admin","manager")
def update_staff(uid_):
    b = request.get_json(force=True)
    mutate("""UPDATE users SET name=?,role=?,department=?,shift=?,phone=?,email=?,
              status=?,avatar_color=?,updated_at=? WHERE id=?""",
           (b.get("name"), b.get("role"), b.get("department","General"),
            b.get("shift","Morning"), b.get("phone",""), b.get("email",""),
            b.get("status","active"), b.get("avatar_color","#C9A84C"),
            now_str(), uid_))
    audit("UPDATE_STAFF","user",uid_)
    return jsonify({"message":"Updated"})

@app.route("/api/staff/<uid_>/status", methods=["PATCH"])
@login_required
@require_roles("admin","manager")
def toggle_staff_status(uid_):
    u = query("SELECT status FROM users WHERE id=?", (uid_,), one=True)
    if not u: return jsonify({"error":"Not found"}),404
    new_status = "inactive" if u["status"]=="active" else "active"
    mutate("UPDATE users SET status=?,updated_at=? WHERE id=?", (new_status,now_str(),uid_))
    audit("TOGGLE_STAFF_STATUS","user",uid_,{"status":new_status})
    return jsonify({"status":new_status})

@app.route("/api/staff/<uid_>", methods=["DELETE"])
@login_required
@require_roles("admin")
def delete_staff(uid_):
    if uid_ == g.user["sub"]:
        return jsonify({"error":"Cannot delete your own account"}),400
    mutate("DELETE FROM users WHERE id=?", (uid_,))
    audit("DELETE_STAFF","user",uid_)
    return jsonify({"message":"Deleted"})

# ══════════════════════════════════════════════════════════════════════════
# BILLING / INVOICES
# ══════════════════════════════════════════════════════════════════════════
@app.route("/api/invoices", methods=["GET"])
@login_required
def get_invoices():
    status = request.args.get("status")
    sql = """SELECT i.*,
             g.first_name||' '||g.last_name as guest_name,
             rm.number as room_number
             FROM invoices i
             LEFT JOIN guests g ON i.guest_id=g.id
             LEFT JOIN reservations r ON i.reservation_id=r.id
             LEFT JOIN rooms rm ON r.room_id=rm.id
             WHERE 1=1"""
    params = []
    if status: sql += " AND i.status=?"; params.append(status)
    sql += " ORDER BY i.issued_at DESC"
    result = []
    for row in query(sql, params):
        d = row_to_dict(row)
        d["extras_detail"] = json.loads(d.get("extras_detail","[]"))
        result.append(d)
    return jsonify(result)

@app.route("/api/invoices/<iid>/pay", methods=["POST"])
@login_required
@require_roles("admin","manager","receptionist")
def pay_invoice(iid):
    b      = request.get_json(force=True)
    amount = float(b.get("amount",0))
    inv    = row_to_dict(query("SELECT * FROM invoices WHERE id=?", (iid,), one=True))
    if not inv: return jsonify({"error":"Not found"}),404
    new_paid = inv["paid_amount"] + amount
    new_paid = min(new_paid, inv["total_amount"])
    status   = "paid" if new_paid >= inv["total_amount"] else "partial"
    paid_at  = now_str() if status=="paid" else None
    mutate("UPDATE invoices SET paid_amount=?,status=?,paid_at=? WHERE id=?",
           (new_paid,status,paid_at,iid))
    if inv.get("reservation_id"):
        mutate("UPDATE reservations SET paid_amount=?,updated_at=? WHERE id=?",
               (new_paid,now_str(),inv["reservation_id"]))
    audit("PAY_INVOICE","invoice",iid,{"amount":amount})
    return jsonify({"paid_amount":new_paid,"status":status})

@app.route("/api/invoices/add-extra/<res_id>", methods=["POST"])
@login_required
@require_roles("admin","manager","receptionist")
def add_extra_charge(res_id):
    b = request.get_json(force=True)
    if not b.get("name") or not b.get("amount"):
        return jsonify({"error":"name and amount required"}),400
    inv = query("SELECT * FROM invoices WHERE reservation_id=?", (res_id,), one=True)
    if not inv: return jsonify({"error":"Invoice not found"}),404
    extras = json.loads(inv["extras_detail"] or "[]")
    extras.append({"name":b["name"],"amount":float(b["amount"])})
    new_extra = inv["extra_charges"] + float(b["amount"])
    new_total = inv["room_charges"] + new_extra
    mutate("UPDATE invoices SET extras_detail=?,extra_charges=?,total_amount=? WHERE id=?",
           (json.dumps(extras),new_extra,new_total,inv["id"]))
    return jsonify({"message":"Extra charge added","new_total":new_total})

# ══════════════════════════════════════════════════════════════════════════
# HOUSEKEEPING
# ══════════════════════════════════════════════════════════════════════════
@app.route("/api/housekeeping", methods=["GET"])
@login_required
def get_housekeeping():
    status = request.args.get("status")
    sql = """SELECT h.*,
             rm.number as room_number, rm.type as room_type,
             u.name as assigned_name
             FROM housekeeping h
             JOIN rooms rm ON h.room_id=rm.id
             LEFT JOIN users u ON h.assigned_to=u.id
             WHERE 1=1"""
    params = []
    if status: sql += " AND h.status=?"; params.append(status)
    sql += " ORDER BY CASE h.priority WHEN 'High' THEN 1 WHEN 'Medium' THEN 2 ELSE 3 END, h.created_at"
    return jsonify(rows_to_list(query(sql, params)))

@app.route("/api/housekeeping/<hid>/status", methods=["PATCH"])
@login_required
def update_hk_status(hid):
    b      = request.get_json(force=True)
    status = b.get("status")
    valid  = ["pending","in_progress","completed","inspected"]
    if status not in valid: return jsonify({"error":f"Status must be {valid}"}),400
    completed_at = now_str() if status=="completed" else None
    mutate("UPDATE housekeeping SET status=?,updated_at=?,completed_at=? WHERE id=?",
           (status,now_str(),completed_at,hid))
    if status == "inspected":
        task = query("SELECT room_id FROM housekeeping WHERE id=?", (hid,), one=True)
        if task: mutate("UPDATE rooms SET status='available',updated_at=? WHERE id=?", (now_str(),task["room_id"]))
    audit("UPDATE_HK_STATUS","housekeeping",hid,{"status":status})
    return jsonify({"message":"Updated"})

@app.route("/api/housekeeping", methods=["POST"])
@login_required
@require_roles("admin","manager","housekeeper","receptionist")
def create_hk_task():
    b = request.get_json(force=True)
    if not b.get("room_id"): return jsonify({"error":"room_id required"}),400
    hid = uid()
    mutate("""INSERT INTO housekeeping(id,room_id,assigned_to,priority,task_type,notes,status)
              VALUES(?,?,?,?,?,?,?)""",
           (hid, b["room_id"], b.get("assigned_to"), b.get("priority","Medium"),
            b.get("task_type","cleaning"), b.get("notes",""), "pending"))
    return jsonify({"id":hid,"message":"Task created"}),201

# ══════════════════════════════════════════════════════════════════════════
# REPORTS
# ══════════════════════════════════════════════════════════════════════════
@app.route("/api/reports/summary", methods=["GET"])
@login_required
@require_roles("admin","manager")
def report_summary():
    month = request.args.get("month", datetime.utcnow().strftime("%Y-%m"))

    rev = query("""SELECT COALESCE(SUM(paid_amount),0) as total,
                   COUNT(*) as invoice_count
                   FROM invoices WHERE strftime('%Y-%m',issued_at)=?""", (month,), one=True)

    occ = query("""SELECT COUNT(*) as c FROM rooms WHERE status='occupied'""", one=True)
    total_rooms = query("SELECT COUNT(*) as c FROM rooms", one=True)["c"]

    res_stats = query("""SELECT status, COUNT(*) as cnt
                         FROM reservations
                         WHERE strftime('%Y-%m',created_at)=?
                         GROUP BY status""", (month,))

    type_rev = query("""SELECT rm.type, COALESCE(SUM(i.paid_amount),0) as rev
                        FROM invoices i
                        JOIN reservations r ON i.reservation_id=r.id
                        JOIN rooms rm ON r.room_id=rm.id
                        WHERE strftime('%Y-%m',i.issued_at)=?
                        GROUP BY rm.type""", (month,))

    return jsonify({
        "month":      month,
        "revenue":    {"total": round(rev["total"],2), "invoice_count": rev["invoice_count"]},
        "occupancy":  {"occupied": occ["c"], "total": total_rooms,
                       "pct": round(occ["c"]/total_rooms*100,1) if total_rooms else 0},
        "reservations_by_status": {r["status"]: r["cnt"] for r in res_stats},
        "revenue_by_room_type":   {r["type"]: round(r["rev"],2) for r in type_rev},
    })

# ══════════════════════════════════════════════════════════════════════════
# NOTIFICATIONS (derived)
# ══════════════════════════════════════════════════════════════════════════
@app.route("/api/notifications", methods=["GET"])
@login_required
def get_notifications():
    today = datetime.utcnow().strftime("%Y-%m-%d")
    notes = []
    # Arrivals today
    arr = query("""SELECT r.res_number, g.first_name||' '||g.last_name as name, rm.number as room
                   FROM reservations r JOIN guests g ON r.guest_id=g.id JOIN rooms rm ON r.room_id=rm.id
                   WHERE r.check_in=? AND r.status='confirmed' LIMIT 5""", (today,))
    for a in arr:
        notes.append({"type":"info","title":f"Arrival today: {a['name']}","body":f"Room {a['room']} · {a['res_number']}","time":"Today"})
    # Departures
    dep = query("""SELECT g.first_name||' '||g.last_name as name, rm.number as room, r.total_amount, r.paid_amount
                   FROM reservations r JOIN guests g ON r.guest_id=g.id JOIN rooms rm ON r.room_id=rm.id
                   WHERE r.check_out=? AND r.status='checked_in' LIMIT 5""", (today,))
    for d in dep:
        balance = d["total_amount"] - d["paid_amount"]
        notes.append({"type":"warning" if balance>0 else "success",
                      "title":f"Departure today: {d['name']}",
                      "body":f"Room {d['room']} · Balance: ${balance:.0f}","time":"Today"})
    # Pending invoices
    pending = query("SELECT COUNT(*) as c FROM invoices WHERE status='pending'", one=True)["c"]
    if pending: notes.append({"type":"warning","title":f"{pending} invoices pending payment","body":"Review billing dashboard","time":"Now"})
    # Maintenance
    maint = query("SELECT number FROM rooms WHERE status='maintenance'")
    for m in maint:
        notes.append({"type":"danger","title":f"Room {m['number']} under maintenance","body":"Assign technician or update status","time":"Active"})
    # HK pending
    hk_pend = query("SELECT COUNT(*) as c FROM housekeeping WHERE status='pending'", one=True)["c"]
    if hk_pend: notes.append({"type":"info","title":f"{hk_pend} housekeeping tasks pending","body":"Assign staff to cleaning tasks","time":"Today"})
    return jsonify(notes)

# ══════════════════════════════════════════════════════════════════════════
# HEALTH
# ══════════════════════════════════════════════════════════════════════════
@app.route("/api/health")
def health():
    db_ok = False
    try:
        query("SELECT 1", one=True)
        db_ok = True
    except Exception:
        pass
    return jsonify({"status":"ok" if db_ok else "degraded","db":db_ok,"time":now_str()})

# ══════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    port  = int(os.environ.get("PORT", 5000))
    debug = os.environ.get("FLASK_DEBUG","0") == "1"
    # Auto-initialise DB if it doesn't exist yet
    if not os.path.exists(DB_PATH):
        import subprocess, sys
        subprocess.run([sys.executable, str(_HERE / "init_db.py")], cwd=str(_HERE), check=True)
    app.run(host="0.0.0.0", port=port, debug=debug)
