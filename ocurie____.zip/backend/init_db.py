#!/usr/bin/env python3
"""
Ocurie Luxury HMS — Database initializer & seeder
Run: python3 init_db.py
"""
import sqlite3, hashlib, uuid, json, os, sys
from datetime import datetime, timedelta
import random

DB_PATH = os.environ.get("DATABASE_PATH", "ocurie_hms.db")

def uid(): return str(uuid.uuid4())

def hash_pw(pw):
    return hashlib.sha256(pw.encode()).hexdigest()

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn

def init_schema(conn):
    schema = open(os.path.join(os.path.dirname(__file__), "schema.sql")).read()
    conn.executescript(schema)
    conn.commit()
    print("✓ Schema applied")

def seed_users(conn):
    users = [
        (uid(), "admin",        hash_pw("admin123"),  "Ocurie Habibu",    "admin",          "Management",  "Morning",  "+255 712 000 001", "admin@ocurieluxury.co.tz",     "active", "#C9A84C"),
        (uid(), "manager",      hash_pw("mgr456"),    "Frank Mwita",      "manager",         "Management",  "Morning",  "+255 712 000 002", "manager@ocurieluxury.co.tz",   "active", "#4A8FE8"),
        (uid(), "reception",    hash_pw("rec789"),    "Elia Enock",       "receptionist",    "Front Desk",  "Morning",  "+255 712 000 003", "elia@ocurieluxury.co.tz",      "active", "#E8A94A"),
        (uid(), "housekeeping", hash_pw("hk321"),     "David Ulomi",      "housekeeper",     "Housekeeping","Morning",  "+255 712 000 004", "david@ocurieluxury.co.tz",     "active", "#888780"),
        (uid(), "fatima",       hash_pw("fatima123"), "Fatima Mohammed",  "receptionist",    "Front Desk",  "Afternoon","+255 712 001 001", "fatima@ocurieluxury.co.tz",    "active", "#E05252"),
        (uid(), "omar",         hash_pw("omar123"),   "Omar Said",        "housekeeper",     "Maintenance", "Morning",  "+255 712 002 002", "omar@ocurieluxury.co.tz",      "active", "#4CAF82"),
        (uid(), "grace",        hash_pw("grace123"),  "Grace Juma",       "housekeeper",     "Housekeeping","Morning",  "+255 712 003 003", "grace@ocurieluxury.co.tz",     "active", "#B464DC"),
        (uid(), "john",         hash_pw("john123"),   "John Kimani",      "receptionist",    "Front Desk",  "Night",    "+255 712 004 004", "john@ocurieluxury.co.tz",      "active", "#64C8B4"),
    ]
    conn.executemany("""
        INSERT OR IGNORE INTO users(id,username,password_hash,name,role,department,shift,phone,email,status,avatar_color)
        VALUES(?,?,?,?,?,?,?,?,?,?,?)
    """, users)
    conn.commit()
    print(f"✓ {len(users)} users seeded")

def seed_rooms(conn):
    rooms = []
    configs = [
        # (number, type, floor, price, capacity, amenities, description)
        ("101","Economy",1, 80, 1, ["WiFi","TV","AC"],          "Cozy economy room with garden view"),
        ("102","Economy",1, 80, 2, ["WiFi","TV","AC"],          "Standard economy double"),
        ("103","Economy",1, 80, 2, ["WiFi","TV","AC"],          "Economy room near pool"),
        ("104","Economy",1, 85, 1, ["WiFi","TV","AC","Minibar"],"Economy plus with minibar"),
        ("105","Standard",1,120, 2, ["WiFi","TV","AC","Safe"],  "Standard room, city view"),
        ("106","Standard",1,120, 2, ["WiFi","TV","AC","Safe"],  "Standard double, garden view"),
        ("107","Standard",1,125, 2, ["WiFi","TV","AC","Safe","Bathtub"], "Standard with bathtub"),
        ("108","Standard",1,120, 3, ["WiFi","TV","AC","Safe","Sofa"],    "Standard triple"),
        ("109","Standard",1,130, 2, ["WiFi","TV","AC","Safe","Minibar"], "Standard plus, pool view"),
        ("110","Standard",1,120, 2, ["WiFi","TV","AC","Safe"],  "Standard double"),
        ("201","Deluxe",  2,180, 2, ["WiFi","TV","AC","Safe","Minibar","Jacuzzi"], "Deluxe ocean view"),
        ("202","Deluxe",  2,180, 2, ["WiFi","TV","AC","Safe","Minibar","Jacuzzi"], "Deluxe garden view"),
        ("203","Deluxe",  2,190, 2, ["WiFi","TV","AC","Safe","Minibar","Jacuzzi","Balcony"], "Deluxe with balcony"),
        ("204","Deluxe",  2,180, 3, ["WiFi","TV","AC","Safe","Minibar","Sofa"],    "Deluxe family room"),
        ("205","Deluxe",  2,185, 2, ["WiFi","TV","AC","Safe","Minibar","Jacuzzi"], "Deluxe corner room"),
        ("206","Deluxe",  2,180, 2, ["WiFi","TV","AC","Safe","Minibar"],           "Deluxe city view"),
        ("207","Deluxe",  2,195, 2, ["WiFi","TV","AC","Safe","Minibar","Jacuzzi","Balcony","Lounge"], "Deluxe premium"),
        ("208","Deluxe",  2,180, 2, ["WiFi","TV","AC","Safe","Minibar"],           "Deluxe garden"),
        ("209","Deluxe",  2,185, 2, ["WiFi","TV","AC","Safe","Minibar","Jacuzzi"], "Deluxe pool view"),
        ("210","Deluxe",  2,180, 2, ["WiFi","TV","AC","Safe","Minibar"],           "Deluxe standard"),
        ("211","Deluxe",  2,180, 2, ["WiFi","TV","AC","Safe","Minibar"],           "Deluxe twin"),
        ("212","Deluxe",  2,180, 2, ["WiFi","TV","AC","Safe","Minibar"],           "Deluxe double"),
        ("215","Deluxe",  2,185, 2, ["WiFi","TV","AC","Safe","Minibar","Jacuzzi"], "Deluxe spa view"),
        ("218","Deluxe",  2,180, 2, ["WiFi","TV","AC","Safe","Minibar"],           "Deluxe classic"),
        ("301","Standard",3,130, 2, ["WiFi","TV","AC","Safe","Minibar"],           "Standard high floor"),
        ("302","Standard",3,125, 2, ["WiFi","TV","AC","Safe"],                     "Standard city view"),
        ("303","Standard",3,120, 2, ["WiFi","TV","AC","Safe"],                     "Standard double"),
        ("305","Standard",3,120, 2, ["WiFi","TV","AC","Safe"],                     "Standard classic"),
        ("307","Standard",3,130, 2, ["WiFi","TV","AC","Safe","Minibar"],           "Standard panoramic"),
        ("309","Standard",3,125, 2, ["WiFi","TV","AC","Safe"],                     "Standard corner"),
        ("311","Standard",3,120, 2, ["WiFi","TV","AC","Safe"],                     "Standard twin"),
        ("312","Standard",3,120, 2, ["WiFi","TV","AC","Safe"],                     "Standard queen"),
        ("401","Suite",   4,320, 2, ["WiFi","TV","AC","Safe","Minibar","Jacuzzi","Balcony","Living Room","Dining Area","Butler Service"], "Presidential Suite — panoramic view"),
        ("402","Suite",   4,320, 2, ["WiFi","TV","AC","Safe","Minibar","Jacuzzi","Balcony","Living Room","Butler Service"],               "Royal Suite — ocean view"),
        ("403","Suite",   4,300, 2, ["WiFi","TV","AC","Safe","Minibar","Jacuzzi","Balcony","Living Room"],                               "Junior Suite — garden view"),
        ("404","Suite",   4,300, 2, ["WiFi","TV","AC","Safe","Minibar","Jacuzzi","Living Room"],                                         "Junior Suite — city view"),
        ("405","Suite",   4,350, 4, ["WiFi","TV","AC","Safe","Minibar","Jacuzzi","Balcony","Living Room","2 Bedrooms","Butler Service"],  "Family Suite — two bedrooms"),
        ("406","Suite",   4,320, 2, ["WiFi","TV","AC","Safe","Minibar","Jacuzzi","Balcony","Living Room","Butler Service"],               "Honeymoon Suite — romance package"),
    ]
    statuses = ["available","available","available","occupied","occupied","cleaning","maintenance"]
    for num,rtype,floor,price,cap,amen,desc in configs:
        rooms.append((
            uid(), num, rtype, floor,
            "available",   # all start available
            price, cap,
            json.dumps(amen), desc, None
        ))
    conn.executemany("""
        INSERT OR IGNORE INTO rooms(id,number,type,floor,status,price_per_night,capacity,amenities,description,notes)
        VALUES(?,?,?,?,?,?,?,?,?,?)
    """, rooms)
    # Set realistic statuses
    all_rooms = conn.execute("SELECT id FROM rooms").fetchall()
    statuses_to_set = ["occupied","occupied","occupied","occupied","occupied",
                       "occupied","occupied","occupied","cleaning","cleaning",
                       "cleaning","maintenance","maintenance","reserved","reserved"]
    for i,row in enumerate(all_rooms[:len(statuses_to_set)]):
        conn.execute("UPDATE rooms SET status=? WHERE id=?", (statuses_to_set[i], row["id"]))
    conn.commit()
    print(f"✓ {len(rooms)} rooms seeded")

def seed_guests(conn):
    guests = [
        (uid(), "Ahmed",   "Hassan",   "ahmed.h@email.com",      "+255 712 345 678", "Tanzania",    "Passport","TZ123456", 1, "VIP guest, prefers ocean view",       4, "2026-03-25"),
        (uid(), "Leila",   "Nkosi",    "leila.n@mail.com",       "+27 82 456 7890",  "South Africa","Passport","ZA789012", 0, "",                                    1, "2026-03-25"),
        (uid(), "Marcus",  "Oliveira", "m.oliveira@email.com",   "+55 11 99 345678", "Brazil",      "Passport","BR345678", 0, "Vegetarian meals",                    2, "2026-03-25"),
        (uid(), "Diego",   "Reyes",    "d.reyes@email.com",      "+52 55 3456 7890", "Mexico",      "Passport","MX901234", 1, "Frequent guest, upgrade when available",6,"2026-03-20"),
        (uid(), "Priya",   "Sharma",   "priya.s@mail.com",       "+91 98 3456 7890", "India",       "Passport","IN567890", 0, "Lactose intolerant",                  3, "2026-03-24"),
        (uid(), "Ivan",    "Petrov",   "i.petrov@email.com",     "+7 916 345 6789",  "Russia",      "Passport","RU234567", 0, "",                                    1, "2026-03-23"),
        (uid(), "Yuki",    "Tanaka",   "yuki.t@mail.com",        "+81 90 3456 7890", "Japan",       "Passport","JP678901", 1, "Requests extra towels, quiet room",   7, "2026-03-25"),
        (uid(), "Zara",    "Kowalski", "z.kow@email.com",        "+48 601 234 567",  "Poland",      "Passport","PL345678", 1, "Champagne on arrival",                5, "2026-03-22"),
        (uid(), "Carlos",  "Mendes",   "c.mendes@email.com",     "+351 91 234 5678", "Portugal",    "Passport","PT123456", 0, "",                                    2, "2026-02-10"),
        (uid(), "Aisha",   "Kamara",   "a.kamara@email.com",     "+232 77 345 678",  "Sierra Leone","NID",     "SL901234", 0, "Halal food required",                 2, "2025-12-01"),
        (uid(), "Elena",   "Vasquez",  "e.vasquez@email.com",    "+34 612 345 678",  "Spain",       "Passport","ES456789", 0, "",                                    1, "2026-01-15"),
        (uid(), "James",   "Okoye",    "j.okoye@email.com",      "+234 802 345 678", "Nigeria",     "Passport","NG789012", 1, "Corporate account – ABC Corp",        8, "2026-03-10"),
        (uid(), "Sofia",   "Andersson","s.andersson@email.com",  "+46 70 123 4567",  "Sweden",      "Passport","SE234567", 0, "",                                    3, "2025-11-20"),
        (uid(), "Ravi",    "Patel",    "r.patel@email.com",      "+44 7911 234567",  "United Kingdom","Passport","UK678901",0,"Gluten free diet",                    4, "2026-02-28"),
        (uid(), "Amina",   "Ndiaye",   "a.ndiaye@email.com",     "+221 77 345 6789", "Senegal",     "Passport","SN345678", 0, "",                                    1, "2026-03-01"),
    ]
    conn.executemany("""
        INSERT OR IGNORE INTO guests(id,first_name,last_name,email,phone,nationality,id_type,id_number,vip,notes,total_stays,last_stay)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
    """, guests)
    conn.commit()
    print(f"✓ {len(guests)} guests seeded")

def seed_reservations(conn):
    guests  = conn.execute("SELECT id,first_name,last_name FROM guests").fetchall()
    rooms   = conn.execute("SELECT id,number,price_per_night FROM rooms ORDER BY number").fetchall()
    admin_id= conn.execute("SELECT id FROM users WHERE username='admin'").fetchone()["id"]

    rmap = {r["number"]: r for r in rooms}
    gmap = {g["first_name"]+" "+g["last_name"]: g for g in guests}

    data = [
        ("Ahmed Hassan",   "401","2026-03-25","2026-03-28","checked_in", "Credit Card",   "Late check-in"),
        ("Leila Nkosi",    "205","2026-03-25","2026-03-26","checked_in", "Cash",          ""),
        ("Marcus Oliveira","312","2026-03-25","2026-03-29","checked_in", "Credit Card",   "Vegetarian meals"),
        ("Zara Kowalski",  "302","2026-03-22","2026-03-25","checked_out","Bank Transfer",  "Champagne on arrival"),
        ("Ivan Petrov",    "110","2026-03-23","2026-03-25","checked_in", "Credit Card",   ""),
        ("Priya Sharma",   "218","2026-03-24","2026-03-25","checked_in", "Credit Card",   ""),
        ("Diego Reyes",    "206","2026-03-20","2026-03-27","checked_in", "Credit Card",   "Upgrade requested"),
        ("Yuki Tanaka",    "209","2026-03-25","2026-03-28","confirmed",  "Bank Transfer",  "Extra towels"),
        ("James Okoye",    "403","2026-03-26","2026-03-30","confirmed",  "Credit Card",   "Corporate booking"),
        ("Ravi Patel",     "105","2026-03-15","2026-03-18","checked_out","Credit Card",   ""),
        ("Elena Vasquez",  "303","2026-03-26","2026-03-28","confirmed",  "Cash",          "Early check-in"),
        ("Carlos Mendes",  "107","2026-03-20","2026-03-22","checked_out","Credit Card",   ""),
    ]

    rows = []
    ctr  = 1
    for guest_name, room_num, ci, co, status, pay, notes in data:
        g = gmap.get(guest_name)
        r = rmap.get(room_num)
        if not g or not r: continue
        ci_d = datetime.strptime(ci, "%Y-%m-%d")
        co_d = datetime.strptime(co, "%Y-%m-%d")
        nights = (co_d - ci_d).days
        total  = nights * r["price_per_night"]
        rows.append((
            uid(), f"RES-{ctr:04d}",
            g["id"], r["id"], ci, co, nights, 2, 0,
            total, total if status == "checked_out" else 0,
            status, pay, notes, "", admin_id
        ))
        ctr += 1

    conn.executemany("""
        INSERT OR IGNORE INTO reservations
        (id,res_number,guest_id,room_id,check_in,check_out,nights,adults,children,
         total_amount,paid_amount,status,payment_method,special_requests,notes,created_by)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    """, rows)
    conn.commit()
    print(f"✓ {len(rows)} reservations seeded")

def seed_housekeeping(conn):
    rooms = conn.execute("SELECT id,number FROM rooms").fetchall()
    david = conn.execute("SELECT id FROM users WHERE username='housekeeping'").fetchone()
    grace = conn.execute("SELECT id FROM users WHERE username='grace'").fetchone()
    omar  = conn.execute("SELECT id FROM users WHERE username='omar'").fetchone()

    tasks = []
    rmap  = {r["number"]: r["id"] for r in rooms}
    configs = [
        ("103","High",  david["id"],"Post check-out deep clean",    "pending"),
        ("204","High",  grace["id"],"Post check-out",                "in_progress"),
        ("211","Medium",grace["id"],"Routine turndown",              "pending"),
        ("305","Medium",david["id"],"Mid-stay refresh",              "in_progress"),
        ("115","Low",   None,       "",                              "pending"),
        ("220","High",  grace["id"],"VIP arrival preparation",       "completed"),
        ("315","Medium",grace["id"],"",                              "completed"),
        ("107","Low",   omar["id"], "Maintenance inspection",        "pending"),
    ]
    for num, prio, uid_, notes, status in configs:
        rid = rmap.get(num)
        if rid:
            tasks.append((uid(), rid, uid_, prio, "cleaning", notes, status))

    conn.executemany("""
        INSERT OR IGNORE INTO housekeeping(id,room_id,assigned_to,priority,task_type,notes,status)
        VALUES(?,?,?,?,?,?,?)
    """, tasks)
    conn.commit()
    print(f"✓ {len(tasks)} housekeeping tasks seeded")

def seed_invoices(conn):
    res_list = conn.execute("""
        SELECT r.id, r.res_number, r.guest_id, r.total_amount, r.paid_amount, r.status
        FROM reservations r
    """).fetchall()

    rows = []
    ctr  = 1042
    for res in res_list:
        extras = []
        extra_total = 0
        if random.random() > 0.4:
            items = [("Minibar",45),("Room Service",80),("Spa",120),("Laundry",40),("Breakfast",60)]
            chosen = random.sample(items, k=random.randint(0,2))
            for name, amt in chosen:
                extras.append({"name": name, "amount": amt})
                extra_total += amt
        total = res["total_amount"] + extra_total
        paid  = total if res["status"] == "checked_out" else res["paid_amount"]
        inv_status = "paid" if res["status"]=="checked_out" else ("pending" if paid==0 else "partial")
        rows.append((
            uid(), f"INV-{ctr}",
            res["id"], res["guest_id"],
            res["total_amount"], extra_total,
            json.dumps(extras), total, paid, inv_status,
            None if inv_status=="pending" else datetime.now().isoformat()
        ))
        ctr += 1

    conn.executemany("""
        INSERT OR IGNORE INTO invoices
        (id,inv_number,reservation_id,guest_id,room_charges,extra_charges,extras_detail,
         total_amount,paid_amount,status,paid_at)
        VALUES(?,?,?,?,?,?,?,?,?,?,?)
    """, rows)
    conn.commit()
    print(f"✓ {len(rows)} invoices seeded")

def main():
    conn = get_db()
    print(f"Initializing database: {DB_PATH}")
    init_schema(conn)
    seed_users(conn)
    seed_rooms(conn)
    seed_guests(conn)
    seed_reservations(conn)
    seed_housekeeping(conn)
    seed_invoices(conn)
    conn.close()
    print("\n✅ Database ready!")

if __name__ == "__main__":
    main()
