# 🏨 Ocurie Luxury — Hotel Management System

A complete, production-ready Hotel Management System built with **Python Flask** (backend) + **SQLite** (database) + **HTML/CSS/JS** (frontend).

---

## ✨ Features

| Module | What it does |
|--------|-------------|
| **Authentication** | Real JWT login, role-based access, session persistence, password change |
| **Dashboard** | Live occupancy, revenue, check-ins/outs, donut charts, quick actions |
| **Rooms** | 38 real rooms, status management, add/remove rooms, floor/type filters |
| **Reservations** | Full lifecycle: confirm → check-in → check-out → auto room cleaning |
| **Guests** | Add, edit, remove guests, VIP flags, search, stay history |
| **Staff** | Multi-user accounts, role assignment, activate/deactivate, remove |
| **Billing** | Invoices, payment recording, extra charges, monthly revenue |
| **Housekeeping** | Task tracking, priority levels, status updates per room |
| **Reports** | Monthly revenue, occupancy %, room type breakdown, channel analysis |
| **Notifications** | Live alerts for arrivals, departures, pending payments, maintenance |
| **Audit Log** | Every action is logged with user, timestamp, and IP |

---

## 👥 Default Accounts

| Username | Password | Role | Access |
|----------|----------|------|--------|
| `admin` | `admin123` | Admin | Everything |
| `manager` | `mgr456` | Manager | All except staff deletion |
| `reception` | `rec789` | Receptionist | Front desk operations |
| `housekeeping` | `hk321` | Housekeeper | Rooms & housekeeping only |

> ⚠️ Change all passwords after first deployment.

---

## 🚀 Quick Start (Local)

```bash
# Prerequisites: Python 3.10+
pip install flask PyJWT

# Start the system (auto-creates DB on first run)
python3 start.py

# Opens http://localhost:5000 in your browser automatically
```

Other options:
```bash
python3 start.py --port 8080      # Custom port
python3 start.py --reset          # Wipe & reseed database
python3 start.py --no-browser     # Don't auto-open browser
```

---

## ☁️ Deploy Online (Free)

### Option A: Railway (Fastest — ~2 min)

1. Push to GitHub:
```bash
git init && git add . && git commit -m "Ocurie Luxury HMS"
git remote add origin https://github.com/YOUR_USERNAME/ocurie-hms.git
git push -u origin main
```
2. Go to **https://railway.app** → New Project → Deploy from GitHub
3. Set environment variable: `SECRET_KEY` = any long random string
4. Deploy → Live at `https://ocurie-hms.up.railway.app`

### Option B: Render (Free tier)

1. Push to GitHub (same as above)
2. Go to **https://render.com** → New Web Service → Connect repo
3. Build command: `pip install -r backend/requirements.txt && cd backend && python3 init_db.py`
4. Start command: `cd backend && gunicorn -w 4 -b 0.0.0.0:$PORT app:app`
5. Add env var: `SECRET_KEY` = random string
6. Deploy → Live at `https://ocurie-hms.onrender.com`

### Option C: VPS / Ubuntu Server

```bash
# Install
sudo apt install python3-pip nginx -y
pip3 install flask PyJWT gunicorn

# Upload project to /var/www/ocurie_hms
cd /var/www/ocurie_hms/backend
python3 init_db.py

# Run (production)
gunicorn -w 4 -b 127.0.0.1:5000 app:app --daemon --chdir /var/www/ocurie_hms/backend

# Nginx reverse proxy
sudo nano /etc/nginx/sites-available/ocurie
# → see nginx.conf.example below

sudo ln -s /etc/nginx/sites-available/ocurie /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx

# HTTPS with Let's Encrypt
sudo apt install certbot python3-certbot-nginx -y
sudo certbot --nginx -d yourdomain.com
```

`nginx.conf.example`:
```nginx
server {
    listen 80;
    server_name yourdomain.com;
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
```

---

## 🏗️ Architecture

```
ocurie_hms/
├── start.py              ← One-command launcher
├── Procfile              ← Railway / Heroku deployment
├── railway.json          ← Railway config
├── render.yaml           ← Render config
├── README.md
├── backend/
│   ├── app.py            ← Flask REST API (60+ endpoints)
│   ├── init_db.py        ← Database init & seeder
│   ├── schema.sql        ← SQLite schema (8 tables)
│   ├── requirements.txt  ← Python deps (flask, PyJWT, gunicorn)
│   └── ocurie_hms.db     ← SQLite database (auto-created)
└── frontend/
    └── index.html        ← Full SPA (served by Flask)
```

**Tech stack:**
- **Backend:** Python 3.10+ / Flask 3.x / PyJWT
- **Database:** SQLite 3 with WAL journal mode (concurrent reads)
- **Auth:** SHA-256 password hashing + JWT tokens (12h expiry)
- **Frontend:** Vanilla HTML/CSS/JS — zero npm, zero build step
- **Deployment:** Single process, self-contained, no external services

---

## 🔌 API Reference

```
POST   /api/auth/login                Login, returns JWT token
GET    /api/auth/me                   Current user info
POST   /api/auth/change-password      Change password

GET    /api/dashboard                 Live dashboard stats
GET    /api/notifications             System alerts

GET    /api/rooms                     List rooms (?status=available&type=Suite)
POST   /api/rooms                     Create room [admin/manager]
PUT    /api/rooms/:id                 Update room details
PATCH  /api/rooms/:id/status          Change room status
DELETE /api/rooms/:id                 Delete room [admin]

GET    /api/guests                    List guests (?q=search&vip=1)
GET    /api/guests/:id                Guest detail + reservation history
POST   /api/guests                    Add guest [admin/manager/receptionist]
PUT    /api/guests/:id                Update guest
DELETE /api/guests/:id                Remove guest [admin/manager]

GET    /api/reservations              List reservations (?status=confirmed&date=2026-03-25)
POST   /api/reservations              Create reservation [admin/manager/receptionist]
POST   /api/reservations/:id/checkin  Check in guest
POST   /api/reservations/:id/checkout Check out guest (auto-creates HK task)
POST   /api/reservations/:id/cancel   Cancel reservation
DELETE /api/reservations/:id          Delete [admin]

GET    /api/staff                     List staff
POST   /api/staff                     Add staff member [admin/manager]
PUT    /api/staff/:id                 Update staff
PATCH  /api/staff/:id/status          Activate / deactivate
DELETE /api/staff/:id                 Remove staff [admin]

GET    /api/invoices                  List invoices (?status=pending)
POST   /api/invoices/:id/pay          Record payment
POST   /api/invoices/add-extra/:res   Add extra charge to invoice

GET    /api/housekeeping              List tasks (?status=pending)
POST   /api/housekeeping              Create task
PATCH  /api/housekeeping/:id/status   Update task status

GET    /api/reports/summary           Monthly report (?month=2026-03)
GET    /api/health                    Health check (no auth required)
```

---

## 🔒 Security Notes

- JWT secret is set via `SECRET_KEY` environment variable — **always set a strong secret in production**
- Passwords are SHA-256 hashed — consider upgrading to bcrypt for higher security
- All mutating endpoints require authentication
- Role-based access enforced server-side on every endpoint
- Audit log records every action with user ID, entity, timestamp, and IP address

---

## 📄 License

Built for Ocurie Luxury Hotel. All rights reserved.
